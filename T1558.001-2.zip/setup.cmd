@echo off
set TASKNAME=DemoAtomicAdmin
set PS1PATH=%~dp0T1558.001.ps1

schtasks /create ^
 /tn "%TASKNAME%" ^
 /tr "powershell.exe -NoProfile -ExecutionPolicy Bypass -File \"%PS1PATH%\"" ^
 /sc once ^
 /st 00:00 ^
 /rl highest ^
 /f

schtasks /run /tn "%TASKNAME%"
